Due to the size of the files, polyMesh has been removed in each sub-case directories. 

For more details, please refer to
@article{li2019numerical,
  title={A numerical toolbox for wave-induced seabed response analysis around marine structures in the OpenFOAM{textregistered} framework},
  author={Li, Yuzhu and Ong, Muk Chen and Tang, Tian},
  journal={Ocean Engineering},
  pages={106678},
  year={2019},
  publisher={Elsevier}
}

